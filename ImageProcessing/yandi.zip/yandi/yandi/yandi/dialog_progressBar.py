from PyQt5 import  QtGui, QtWidgets, QtCore
from PyQt5.QtWidgets import *
from Ui_dialog_progressBar import Ui_Dialog


class Dialog(QDialog, Ui_Dialog):
    def __init__(self, parent=None):
        super(Dialog, self).__init__(parent)
        self.setupUi(self)

        self.setFixedSize(self.width(), self.height())
        self.setWindowTitle("眼底图像纠偏融合软件")

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    ui = Dialog()
    ui.show()
    sys.exit(app.exec_())        
