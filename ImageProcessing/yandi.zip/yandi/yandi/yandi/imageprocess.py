import cv2
import numpy as np


def blur_demo(image):

    dst = cv2.blur(image, (1, 15))
    cv2.imshow("emo", dst)

src = cv2.imread("./2.jpg")
img = cv2.resize(src,None,fx=0.8,fy=0.8,interpolation=cv2.INTER_CUBIC)

blur_demo(img)

cv2.waitKey(0)
cv2.destroyAllWindows()