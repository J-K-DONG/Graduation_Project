from PyQt5 import QtCore, QtGui, QtWidgets
import os
from PyQt5.QtGui import *
from custom_widgets import Canvas
from Ui_main import Ui_MainWindow
import dialog_progressBar
import cv2
from skimage import io,transform,filters,color
from skimage import img_as_ubyte
import numpy as np


class Yandi(QtWidgets.QMainWindow,Ui_MainWindow):

    def __init__(self, parent=None):
        super().__init__(parent=parent)

        self.setupUi(self)
        self.listWidget.clear()

        self.pic_path_ls = []
        self.pic_name_ls = []
        self.pic_current_index = 0
        self.setWindowIcon(QIcon('ico.png'))

        # 菜单栏
        self.picture_import.triggered.connect(self.load_image_ls)
        self.save_result.triggered.connect(self.saveFileDialog)

   #     self.dialog = dialog_progressBar.Dialog(self)
   #     self.mean_denoising.triggered.connect(self.dialog.exec)  # 均值去噪
   #     self.gauss_denoising.triggered.connect(self.dialog.exec)  # 高斯去噪
   #     self.spacePyramid_fusion.triggered.connect(self.dialog.exec)  # 空间金字塔融合
   #     self.deep_fusion.triggered.connect(self.dialog.exec)  # 深度融合

        self.mean_denoising.triggered.connect(self.mean_denoising_method)  # 均值去噪
        self.gauss_denoising.triggered.connect(self.gauss_denoising_method)  # 高斯去噪
        self.spacePyramid_fusion.triggered.connect(self.spacePyramid_fusion_method)  # 空间金字塔融合
        self.deep_fusion.triggered.connect(self.deep_fusion_method)  # 深度融合


        # 左边
        self.left_keep.hide()
        self.left_viewer = Canvas(self.layoutWidget)
        self.left_layout.addWidget(self.left_viewer)
        self.left_viewer.setMinimumSize(QtCore.QSize(150, 0))
        self.left_viewer.side = 'left'
        self.left_img = None  # pixMap object

        # 右边
        self.right_keep.hide()
        self.layoutWidget.update()
        self.right_viewer = Canvas(self.layoutWidget)
        self.right_layout.addWidget(self.right_viewer)
        self.right_viewer.setMinimumSize(QtCore.QSize(150, 0))
        self.right_viewer.side = 'right'
        self.right_img = None

        # 双向绑定
        self.right_viewer.make_connection(self.left_viewer)
        self.left_viewer.make_connection(self.right_viewer)

        # 列表右键
        self.contextMenu = QtWidgets.QMenu(self)
        self.contextDeleteAction = QtWidgets.QAction(u'删除', self)
        self.contextMenu.addAction(self.contextDeleteAction)
        self.listWidgetItemsToDelete = []

        self.listWidget.clicked.connect(self.check_item_clicked)
        self.listWidget.customContextMenuRequested.connect(self.showContextMenu)
        self.contextDeleteAction.triggered.connect(self.remove_selected)

        # 列表操作
    def showContextMenu(self, pos):

        print(pos)

        items = self.listWidget.selectedIndexes()
        print(items)

        if not items:
            return
        self.listWidgetItemsToDelete = []
        for i in items:
            self.listWidgetItemsToDelete.append(i.row())
        self.contextMenu.show()
        self.contextMenu.exec_(QtGui.QCursor.pos())

    def remove_selected(self):
        for i in self.listWidgetItemsToDelete:
            self.listWidget.removeItemWidget(self.listWidget.takeItem(i))
        self.pic_path_ls = [j for i, j in enumerate(self.pic_path_ls) if i not in self.listWidgetItemsToDelete]
        self.pic_name_ls = [j for i, j in enumerate(self.pic_name_ls) if i not in self.listWidgetItemsToDelete]
        if self.pic_current_index in self.listWidgetItemsToDelete and self.pic_path_ls:
            self.pic_current_index = 0
            img_path = self.pic_path_ls[self.pic_current_index]

            self.left_img = QtGui.QPixmap(img_path)
            self.left_viewer.setPhoto(self.left_img)

            self.listWidgetItemsToDelete = []

        if not self.pic_path_ls:
            self.left_viewer.setPhoto()
            self.right_viewer.setPhoto()

    def check_item_clicked(self, pos):
        self.pic_current_index = pos.row()
        self.display_image()

    def refresh_list_box(self):
        self.listWidget.clear()
        self.listWidget.addItems(self.pic_name_ls)

    def load_image_ls(self):
        files = self.openFileNamesDialog()
        if not files:
            return
        self.pic_path_ls = files
        self.pic_name_ls = [os.path.split(i)[-1] for i in files]
        self.refresh_list_box()
        self.pic_current_index = 0

        img_path = self.pic_path_ls[self.pic_current_index]

        self.left_img = QtGui.QPixmap(img_path)
        self.left_viewer.setPhoto(self.left_img)


        self.right_img = None

        self.right_viewer.setPhoto(self.right_img)

    def display_image(self):
        img_path = self.pic_path_ls[self.pic_current_index]
        self.left_img = QtGui.QPixmap(img_path)

        self.right_img = None
        self.left_viewer.setPhoto(self.left_img)

        #self.right_viewer.setPhoto(self.right_img)


    def openFileNamesDialog(self):
        options = QtWidgets.QFileDialog.Options()
     #   options |= QtWidgets.QFileDialog.DontUseNativeDialog
        files, _ = QtWidgets.QFileDialog.getOpenFileNames(
            self, "导入图集", "",
            "JEPG Files (*.jpeg);;All Files (*.*)", options=options)
        if files:
            print(files)
        return files



    def saveFileDialog(self):
        print('save picture')
        if not self.right_viewer.hasPhoto():
            return
        options = QtWidgets.QFileDialog.Options()
        #options |= QtWidgets.QFileDialog.DontUseNativeDialog
        fileName, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "图像保存","",
            "All Files (*);;JPG Files (*.jpg)",options=options)
        if fileName:
            print(fileName)
        # write file to file

    def mean_denoising_method(self):
        self.left_viewer.fitInView()
        img_path = self.pic_path_ls[self.pic_current_index]
        img1 = cv2.imread(img_path, cv2.IMREAD_COLOR)
        img1 = cv2.cvtColor(img1, cv2.COLOR_BGR2RGB)

        img = cv2.fastNlMeansDenoisingColored(img1,None,6,10,7,21)

        height, width, channel = img.shape
        bytesPerLine = 3 * width
        image = QtGui.QImage(img, width, height, bytesPerLine, QtGui.QImage.Format_RGB888)
        print('987')
        self.right_img = QtGui.QPixmap(image)
        self.right_viewer.setPhoto(self.right_img)

        print('Under Construction')

    def gauss_denoising_method(self):
        print('Under Construction')

    def spacePyramid_fusion_method(self):
        print('Under Construction')

    def deep_fusion_method(self):
        print('Under Construction')


if __name__ == '__main__':
    import sys
    app = QtWidgets.QApplication(sys.argv)
    m = Yandi()
    m.show()
    sys.exit(app.exec_())